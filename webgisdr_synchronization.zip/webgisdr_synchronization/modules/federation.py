import logging
from arcgis.gis import GIS


def validate_federation(portal_url, username, password, environment_name):
    try:
        logging.info(f"{environment_name} federation validation started")

        gis = GIS(
            portal_url,
            username,
            password,
            verify_cert=False
        )

        logging.info(f"Successfully connected to {environment_name} portal")

        validation_results = gis.admin.federation.validate_all()

        # Validate response
        if validation_results is None:
            raise ValueError(
                f"{environment_name} federation validation returned None"
            )

        if not isinstance(validation_results, dict):
            raise ValueError(
                f"{environment_name} federation validation returned unexpected result type"
            )

        if 'status' not in validation_results:
            raise ValueError(
                f"{environment_name} federation validation results missing 'status' field"
            )

        status = validation_results.get('status', '').lower()

        if status == "success":
            logging.info(f"{environment_name} federation validation successful")
        else:
            raise Exception(
                f"{environment_name} federation validation failed: {validation_results}"
            )

    except Exception as ex:
        logging.error(f"{environment_name} federation validation ERROR: {str(ex)}")
        raise
