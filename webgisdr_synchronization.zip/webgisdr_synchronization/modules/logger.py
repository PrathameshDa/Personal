import os
import logging
from datetime import datetime, timedelta
from colorama import Fore, Style


def setup_logging():
    class LogColors:
        INFO = Fore.GREEN
        WARNING = Fore.YELLOW
        ERROR = Fore.RED
        CRITICAL = Fore.MAGENTA
        RESET = Style.RESET_ALL

    class ColoredFormatter(logging.Formatter):
        def format(self, record):
            if record.levelno == logging.INFO:
                record.msg = f"{LogColors.INFO}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.WARNING:
                record.msg = f"{LogColors.WARNING}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.ERROR:
                record.msg = f"{LogColors.ERROR}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.CRITICAL:
                record.msg = f"{LogColors.CRITICAL}{record.msg}{LogColors.RESET}"
            return super().format(record)

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    log_directory = "Logs"
    if not os.path.exists(log_directory):
        os.makedirs(log_directory, exist_ok=True)

    file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    console_formatter = ColoredFormatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    log_file_path = os.path.join(log_directory, datetime.now().strftime("logfile_%Y-%m-%d.log"))
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(file_formatter)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    clean_old_logs(log_directory)


def clean_old_logs(log_directory):
    retention_period = timedelta(days=7)
    cutoff_time = datetime.now() - retention_period
    for filename in os.listdir(log_directory):
        file_path = os.path.join(log_directory, filename)
        if os.path.isfile(file_path):
            file_mod_time = datetime.fromtimestamp(os.path.getmtime(file_path))
            if file_mod_time < cutoff_time:
                os.remove(file_path)
                logging.info(f"Deleted old log file: '{filename}'")
