import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import logging
from datetime import datetime

def send_log_email(settings, status="Success"):
    """
    Send the log file as an attachment after script completion.

    Args:
        settings: Configuration settings object (dynaconf)
        status: "Success" or "Failed" to indicate script outcome
    """
    log_file_path = os.path.join("Logs", datetime.now().strftime("logfile_%Y-%m-%d.log"))

    msg = MIMEMultipart()
    msg['Subject'] = f"{settings.email.subject_prefix} - {status} - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    msg['From'] = settings.email.smtp_username
    msg['To'] = ', '.join(settings.email.recipients)

    # Read log file for email body
    try:
        with open(log_file_path, 'r') as log_file:
            log_contents = log_file.read()
    except Exception as e:
        logging.error(f"Failed to read log file '{log_file_path}': {e}")
        log_contents = "Could not read log file."

    # Color-coded HTML body
    colored_logs = ""
    for line in log_contents.split('\n'):
        if "CRITICAL" in line:
            colored_logs += f"<span style='color: magenta;'>{line}</span><br>"
        elif "ERROR" in line:
            colored_logs += f"<span style='color: red;'>{line}</span><br>"
        elif "WARNING" in line:
            colored_logs += f"<span style='color: orange;'>{line}</span><br>"
        elif "INFO" in line:
            colored_logs += f"<span style='color: green;'>{line}</span><br>"
        else:
            colored_logs += f"{line}<br>"

    body = f"<html><body><h3>WebGISDR Synchronization - {status}</h3>{colored_logs}</body></html>"
    msg.attach(MIMEText(body, "html"))

    # Attach log file
    if os.path.exists(log_file_path):
        try:
            with open(log_file_path, 'rb') as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(log_file_path)}"')
            msg.attach(part)
        except Exception as e:
            logging.error(f"Failed to attach log file: {e}")

    try:
        mail = smtplib.SMTP(settings.email.smtp_server, settings.email.smtp_port)
        mail.ehlo()
        mail.starttls()
        if settings.email.smtp_password:
            mail.login(settings.email.smtp_username, settings.email.smtp_password)
        mail.sendmail(msg['From'], settings.email.recipients, msg.as_string())
        mail.quit()
        logging.info(f"Log email sent successfully to: {settings.email.recipients}")
    except Exception as e:
        logging.error(f"Failed to send log email: {e}")