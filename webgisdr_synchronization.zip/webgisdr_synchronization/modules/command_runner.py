import subprocess
import logging


def run_command(command, step_name, cwd):
    try:
        logging.info(f"{step_name} started")

        process = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True
        )

        if process.stdout:
            for line in process.stdout.strip().splitlines():
                logging.info(f"{step_name} | {line}")

        if process.stderr:
            for line in process.stderr.strip().splitlines():
                logging.warning(f"{step_name} | {line}")

        if process.returncode != 0:
            raise Exception(
                f"{step_name} failed with return code: {process.returncode}"
            )

        logging.info(f"{step_name} completed successfully")

    except Exception as ex:
        logging.error(f"{step_name} ERROR: {str(ex)}")
        raise
