import logging
import sys
from colorama import init
from dynaconf import Dynaconf

from modules.logger import setup_logging
from modules.federation import validate_federation
from modules.command_runner import run_command
from modules.email_handler import send_log_email

# Initialize colorama
init(autoreset=True)

# -----------------------------------------------------------------------------
# Configuration (loaded from config.yaml via dynaconf)
# -----------------------------------------------------------------------------

settings = Dynaconf(settings_files=["config.yaml"])

WEBGISDR_PATH = settings.webgisdr_path

# PROD Details
PROD_PORTAL_URL = settings.prod.portal_url
PROD_USERNAME = settings.prod.username
PROD_PASSWORD = settings.prod.password

# DR Details
DR_PORTAL_URL = settings.dr.portal_url
DR_USERNAME = settings.dr.username
DR_PASSWORD = settings.dr.password

# Commands
PROD_EXPORT_CMD = settings.commands.prod_export
DR_IMPORT_CMD = settings.commands.dr_import


# -----------------------------------------------------------------------------
# Main Execution
# -----------------------------------------------------------------------------

def main():
    setup_logging()

    try:
        logging.info("===================================================")
        logging.info("WebGISDR Full DR Process Started")
        logging.info("===================================================")

        # ---------------------------------------------------------------------
        # Step 1 - Add Hosts
        # ---------------------------------------------------------------------

        logging.info("Step 1 - Adding hosts entries")
        run_command(
            "powershell -ExecutionPolicy Bypass -File add_hosts.ps1",
            "Add Hosts",
            "."
        )

        # ---------------------------------------------------------------------
        # Step 2 - PROD Federation Check
        # ---------------------------------------------------------------------

        logging.info("Step 2 - PROD federation check")
        validate_federation(
            PROD_PORTAL_URL,
            PROD_USERNAME,
            PROD_PASSWORD,
            "PROD"
        )

        # ---------------------------------------------------------------------
        # Step 3 & 4 - PROD Export
        # ---------------------------------------------------------------------

        logging.info("Step 3 - PROD webgisdr full export start")

        run_command(
            PROD_EXPORT_CMD,
            "PROD WebGISDR Export",
            WEBGISDR_PATH
        )

        logging.info("Step 4 - PROD webgisdr full export complete")

        # ---------------------------------------------------------------------
        # Step 5 - DR Federation Check
        # ---------------------------------------------------------------------

        logging.info("Step 5 - DR federation check")

        validate_federation(
            DR_PORTAL_URL,
            DR_USERNAME,
            DR_PASSWORD,
            "DR"
        )

        # ---------------------------------------------------------------------
        # Step 6 & 7 - DR Import
        # ---------------------------------------------------------------------

        logging.info("Step 6 - DR webgisdr full import start")

        run_command(
            DR_IMPORT_CMD,
            "DR WebGISDR Import",
            WEBGISDR_PATH
        )

        logging.info("Step 7 - DR webgisdr full import complete")

        # ---------------------------------------------------------------------
        # Step 8 - Remove Hosts
        # ---------------------------------------------------------------------

        logging.info("Step 8 - Removing hosts entries")
        run_command(
            "powershell -ExecutionPolicy Bypass -File remove_hosts.ps1",
            "Remove Hosts",
            "."
        )

        logging.info("===================================================")
        logging.info("WebGISDR DR Process Completed Successfully")
        logging.info("===================================================")

        send_log_email(settings, status="Success")

    except Exception as ex:
        logging.critical("===================================================")
        logging.critical(f"PROCESS FAILED: {str(ex)}")
        logging.critical("===================================================")

        send_log_email(settings, status="Failed")


# -----------------------------------------------------------------------------
# Script Entry Point
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    main()
