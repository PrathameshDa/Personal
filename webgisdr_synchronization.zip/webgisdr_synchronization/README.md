# WebGISDR Synchronization

Automated disaster recovery synchronization tool for ArcGIS Enterprise using WebGISDR. This script exports from a Production portal and imports into a DR portal, with federation validation and hosts file management at each step.

## Workflow

1. Add hosts entries (`add_hosts.ps1`)
2. Validate PROD portal federation
3. Export PROD environment via `webgisdr.bat`
4. Validate DR portal federation
5. Import into DR environment via `webgisdr.bat`
6. Remove hosts entries (`remove_hosts.ps1`)
7. Email log file upon completion (success or failure)

## Project Structure

```
webgisdr_synchronization/
├── main.py                # Entry point - orchestrates the DR process
├── main.bat               # Batch launcher
├── config.yaml            # Configuration (portals, commands, email)
├── add_hosts.ps1          # Adds required hosts file entries
├── remove_hosts.ps1       # Removes hosts file entries after completion
├── modules/
│   ├── logger.py          # Logging setup with colored console output
│   ├── federation.py      # Portal federation validation
│   ├── command_runner.py  # Subprocess command execution with log capture
│   └── email_handler.py   # Email notification with log attachment
├── Logs/                  # Auto-generated daily log files
├── pyproject.toml
└── uv.lock
```

## Prerequisites

- Python >= 3.11
- ArcGIS Enterprise with WebGISDR configured
- Access to both PROD and DR portal environments
- SMTP server for email notifications

## Installation

```bash
uv sync
```

## Configuration

Edit `config.yaml` with your environment details:

```yaml
webgisdr_path: "E:/webgisdr"

prod:
  portal_url: "https://your-prod-portal/portal"
  username: "portaladmin"
  password: "your-password"

dr:
  portal_url: "https://your-dr-portal/portal"
  username: "portaladmin"
  password: "your-password"

commands:
  prod_export: "webgisdr.bat -e -f PROD_webgisdr.properties"
  dr_import: "webgisdr.bat -i -f DR_webgisdr.properties"

email:
  smtp_server: "smtp.example.com"
  smtp_port: 587
  smtp_username: "sender@example.com"
  smtp_password: ""
  recipients:
    - "recipient@example.com"
  subject_prefix: "WebGISDR Synchronization"
```

## Usage

```bash
python main.py
```

## Logging

- Logs are written to `Logs/logfile_YYYY-MM-DD.log`
- Console output is color-coded (green=INFO, yellow=WARNING, red=ERROR, magenta=CRITICAL)
- Logs older than 7 days are automatically deleted
- Log file is emailed as an attachment after script completion