#from modules.get_secrets import get_secrets
from modules.setup_logging import setup_logging
from modules.gdbmaintenance import gdbmaintenance
from modules.send_email_notification import send_email_notification
from dynaconf import Dynaconf

def main():
    # Initialize Dynaconf with the path to your config.yaml
    settings = Dynaconf(settings_files=['config.yaml'])
    #settings = get_secrets()  # Retrieve credentials from key vault
    setup_logging()  # Color-coded logging function
    gdbmaintenance(settings)  # Run export site operation for portal & all servers at the same time
    send_email_notification(settings)
    
if __name__ == '__main__':
    main()