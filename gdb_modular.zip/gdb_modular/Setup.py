import os
import pandas as pd
import arcpy
import logging

# ---------- CONFIG ----------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASES_DIR = os.path.join(BASE_DIR, "Databases")
EXCEL_PATH = os.path.join(BASE_DIR, "GDBMaintenance_info.xlsx")

# ---------- LOGGING ----------
logging.basicConfig(
    level=logging.DEBUG,  # Change to INFO in production
    format="%(asctime)s - %(levelname)s - %(message)s"
)


# ---------- GENERIC GLOBAL VALUE EXTRACTOR ----------
def extract_common_value(df, column_name):
    for value in df[column_name]:
        if pd.notna(value):
            return str(value).strip()
    raise ValueError(f"No valid value found for column: {column_name}")


# ---------- INSTANCE TYPE ----------
def get_database_platform(instance_type):
    normalized = instance_type.strip().lower()

    mapping = {
        "sql server": "SQL_SERVER",
        "oracle": "ORACLE",
        "postgresql": "POSTGRESQL"
    }

    if normalized not in mapping:
        raise ValueError(f"Unsupported instance_type: {instance_type}")

    return mapping[normalized]


# ---------- SDE USER (GLOBAL OPTIONAL) ----------
def extract_sde_credentials(df):
    for _, row in df.iterrows():
        sde_user = row.get("sde_user")
        sde_pwd = row.get("sde_password")

        if pd.notna(sde_user) and pd.notna(sde_pwd):
            logging.info("Using global SDE credentials")
            return str(sde_user).strip(), str(sde_pwd).strip()

    logging.warning("No SDE credentials found in Excel.")
    return None, None


# ---------- ROOT ----------
def ensure_databases_root():
    if not os.path.exists(DATABASES_DIR):
        os.makedirs(DATABASES_DIR)
        logging.info(f"Created parent Databases folder: {DATABASES_DIR}")
    else:
        logging.info(f"Databases folder already exists: {DATABASES_DIR}")


# ---------- FOLDER ----------
def create_folder_structure(db_name):
    db_path = os.path.join(DATABASES_DIR, db_name)
    dataowners_path = os.path.join(db_path, "DataOwners")
    admin_path = os.path.join(db_path, "Admin")

    os.makedirs(dataowners_path, exist_ok=True)
    os.makedirs(admin_path, exist_ok=True)

    return db_path, dataowners_path, admin_path


# ---------- CONNECTION ----------
def create_sde_connection(out_folder, connection_name, db_platform, instance, database, username, password):
    out_path = os.path.join(out_folder, connection_name)

    if os.path.exists(out_path):
        logging.info(f"Connection already exists: {out_path}")
        return

    try:
        arcpy.management.CreateDatabaseConnection(
            out_folder_path=out_folder,
            out_name=connection_name,
            database_platform=db_platform,
            instance=instance,
            account_authentication="DATABASE_AUTH",
            username=username,
            password=password,
            save_user_pass="SAVE_USERNAME",
            database=database
        )
        logging.info(f"Created connection: {out_path}")

    except Exception as e:
        logging.error(f"Failed to create connection {connection_name}: {str(e)}")


# ---------- MAIN ----------
def process_excel():
    df = pd.read_excel(EXCEL_PATH)

    # ---------- GLOBAL VALUES ----------
    instance = extract_common_value(df, "instance")
    instance_type = extract_common_value(df, "instance_type")
    admin_user = extract_common_value(df, "admin_user")
    admin_pwd = extract_common_value(df, "admin_password")

    db_platform = get_database_platform(instance_type)

    sde_user, sde_pwd = extract_sde_credentials(df)

    logging.info(f"Using instance: {instance}")
    logging.info(f"Using instance_type: {instance_type}")
    logging.info(f"Using admin_user: {admin_user}")

    # ---------- LOOP DATABASES ----------
    for _, row in df.iterrows():

        logging.debug(f"Row data: {row.to_dict()}")

        database = row.get("database")

        if pd.isna(database):
            continue

        data_owner = row.get("data_owner")
        data_owner_pwd = row.get("data_owner_password")

        logging.info(f"Processing database: {database}")

        db_path, dataowners_path, admin_path = create_folder_structure(database)

        # ---------- ADMIN ----------
        create_sde_connection(
            admin_path,
            "admin_connection.sde",
            db_platform,
            instance,
            database,
            admin_user,
            admin_pwd
        )

        # ---------- DATA OWNER ----------
        if pd.notna(data_owner) and pd.notna(data_owner_pwd):
            dataowner_conn_name = f"{str(data_owner).strip()}_connection.sde"

            create_sde_connection(
                dataowners_path,
                dataowner_conn_name,
                db_platform,
                instance,
                database,
                str(data_owner).strip(),
                str(data_owner_pwd).strip()
            )
        else:
            logging.warning(f"Skipping data owner connection for {database} due to missing credentials")

        # ---------- SDE ----------
        if sde_user and sde_pwd:
            create_sde_connection(
                dataowners_path,
                "sde_connection.sde",
                db_platform,
                instance,
                database,
                sde_user,
                sde_pwd
            )


# ---------- ENTRY ----------
if __name__ == "__main__":
    ensure_databases_root()
    process_excel()

    logging.info("Folder structure and SDE connections created successfully.")