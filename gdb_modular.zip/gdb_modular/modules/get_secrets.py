from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient
from dynaconf import Dynaconf
import logging

# Initialize Dynaconf with the path to your config.yaml
settings = Dynaconf(settings_files=['config.yaml'])

def get_secrets():
    logging.info("Started fetching variables from configuration file")
    
    # Extract the configuration details
    tenant_id = settings.azure.tenant_id
    client_id = settings.azure.client_id
    client_secret = settings.azure.client_secret
    key_vault = settings.azure.key_vault
    
    new_credential = ClientSecretCredential(
        tenant_id=tenant_id,
        additionally_allowed_tenants=tenant_id,
        client_id=client_id,
        client_secret=client_secret
    )
    
    secret_client = SecretClient(
        vault_url=key_vault,
        credential=new_credential
    )
    
    # Retrieve secrets using the secret client
    settings.azure.portal_username = secret_client.get_secret(settings.azure.portal_username).value
    settings.azure.portal_password = secret_client.get_secret(settings.azure.portal_password).value
    settings.azure.smtp_username = secret_client.get_secret(settings.azure.smtp_username).value
    settings.azure.smtp_password = secret_client.get_secret(settings.azure.smtp_password).value
    settings.azure_storage.connection_string = secret_client.get_secret(settings.azure_storage.connection_string).value

    logging.info("Successfully fetched all variables from configuration file")
    return settings