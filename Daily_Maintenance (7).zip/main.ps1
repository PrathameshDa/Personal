# PowerShell script to run main.py using UV
# Daily Maintenance Script Runner

Write-Host "===================================="
Write-Host "Daily Maintenance Script Runner"
Write-Host "Using UV Package Manager"
Write-Host "===================================="
Write-Host ""

# Set working directory to script location
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir
Write-Host "Current directory: $(Get-Location)"
Write-Host ""

# Check if UV is installed
Write-Host "Checking UV installation..."
if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: UV is not installed or not in PATH"
    Write-Host "Please install UV first: pip install uv"
    Read-Host "Press Enter to exit..."
    exit 1
}
Write-Host "UV is installed successfully!"
Write-Host ""

# Check if pyproject.toml exists
if (-not (Test-Path "pyproject.toml")) {
    Write-Host "ERROR: pyproject.toml not found"
    Write-Host "Please ensure pyproject.toml is in the project directory"
    Read-Host "Press Enter to exit..."
    exit 1
}
Write-Host "Found pyproject.toml"
Write-Host ""

# Check if main.py exists
if (-not (Test-Path "main.py")) {
    Write-Host "ERROR: main.py not found"
    Write-Host "Please ensure main.py is in the project directory"
    Read-Host "Press Enter to exit..."
    exit 1
}
Write-Host "Found main.py"
Write-Host ""

# Set Python path
$env:PYTHONPATH = Get-Location

Write-Host "Starting Daily Maintenance Script..."
Write-Host "===================================="
Write-Host ""

# Option 1: Try UV with pyproject.toml (modern approach)
Write-Host "Attempting to sync and run with UV..."
Write-Host "Step 1: Syncing dependencies..."
uv sync
$exitCode = $LASTEXITCODE
Write-Host ""
Read-Host "Press Enter to exit..."
exit $exitCode