import logging
import os
from modules_email.email_handler import send_failure_email
from tenacity import retry, stop_after_attempt, wait_fixed

@retry(stop=stop_after_attempt(2), wait=wait_fixed(10))
def export_portal_site(settings, gis):
    """
    Export ArcGIS Portal site with comprehensive exception handling.
    
    Args:
        settings: Configuration settings object
        gis: GIS connection object
        
    Returns:
        str: Success message if export was successful, None if failed
    """
    operation = "Daily Maintenance Exportsite Portal"
    
    try:
        logging.info("Exportsite Portal process started")
        
        # Validate required parameters
        if not settings:
            raise ValueError("Settings object is None or empty")
        if not gis:
            raise ValueError("GIS connection object is None or empty")
        
        # Construct and validate the backup location
        try:
            if hasattr(settings.arcgis, 'linux_backup_location') and settings.arcgis.linux_backup_location:
                location = f"{settings.arcgis.linux_backup_location}/portal"
            elif hasattr(settings.arcgis, 'backup_location') and settings.arcgis.backup_location:
                location = f"{settings.arcgis.backup_location}\\portal"
            else:
                raise ValueError("No backup location configured in settings")
            
            # Validate backup location directory exists or can be created
            backup_dir = os.path.dirname(location)
            if not os.path.exists(backup_dir):
                try:
                    os.makedirs(backup_dir, exist_ok=True)
#                    logging.info(f"Created backup directory: {backup_dir}")
                except OSError as e:
                    raise ValueError(f"Cannot create backup directory {backup_dir}: {str(e)}")
            
#           logging.info(f"Portal backup location: {location}")
        except Exception as e:
            error_message = f"Failed to configure backup location for Portal: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return None
        
        # Validate GIS admin and site objects
        try:
            if not hasattr(gis, 'admin') or not gis.admin:
                raise ValueError("GIS object does not have a valid admin property")
            if not hasattr(gis.admin, 'site') or not gis.admin.site:
                raise ValueError("GIS admin object does not have a valid site property")
            
            portal = gis.admin.site
#            logging.info("Portal admin site object validated successfully")
        except Exception as e:
            error_message = f"Portal site validation failed: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return None
        
        # Attempt to export the portal site
        try:
            export_result = portal.export_site(location=location)
            
            # Validate export result (some operations might return different types)
            if export_result is False:
                raise ValueError("Export operation explicitly returned False - operation failed")
            
            logging.info("Export site backup completed successfully for Portal")
            success_message = "Exportsite backup is successful: Portal"
            
            return success_message
            
        except Exception as e:
            error_message = f"Failed to export Portal site: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return None
    
    except Exception as e:
        # Catch-all exception handler for any unexpected errors
        error_message = f"Unexpected error during Portal export operation: {str(e)}"
        logging.error(error_message)
        try:
            send_failure_email(settings, error_message, operation)
        except Exception as email_error:
            logging.error(f"Failed to send failure email: {str(email_error)}")
        return None