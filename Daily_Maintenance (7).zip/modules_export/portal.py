import logging
import requests
import json
 
# Disable SSL warnings
requests.packages.urllib3.disable_warnings()

 
def generate_token(settings, gis):
    username = settings.secret_provider.portal_username
    password = settings.secret_provider.portal_password
    portal_admin_url = 'https://portalmachine.domain.com:7443/arcgis/portaladmin'
    token_url = 'https://webmachine/portal/sharing/rest/generateToken'
    try:
        #logging.info("Starting the process to generate an authentication token for the portal.")
        params = {
            'username': username,
            'password': password,
            'referer': portal_admin_url,
            'f': 'json'
        }
        #logging.info(f"Sending authentication request to token endpoint: {token_url}")
        response = requests.post(token_url, data=params, verify=False, timeout=300)
        token_data = response.json()
        #logging.debug(f"Token response received: {json.dumps(token_data, indent=2)}")
        if 'error' in token_data:
            logging.error(f"Token generation failed: {token_data['error']['message']}")
            return None
        #logging.info("Authentication token was generated successfully.")
        return token_data['token']
    except requests.Timeout:
        logging.error("A timeout occurred while generating the authentication token for the portal.")
        return None
    except Exception as error:
        logging.error(f"An unexpected error occurred while generating the authentication token: {str(error)}")
        return None
 
def export_portal_site(settings, gis):

    export_url = 'https://portalmachine.domain.com:7443/arcgis/portaladmin/exportSite'
    backup_location = r'\\ARCGISSERVER\exportsite_backup\portal'  # Using raw string for Windows path
    
    try:
        logging.info("Starting the portal export process.")
        token = generate_token(settings, gis)
        if not token:
            logging.error("Cannot proceed with portal export because a valid authentication token could not be obtained.")
            return
        #logging.info(f"Exporting portal site to backup location: '{backup_location}'.")
        data = {
            'location': backup_location,
            'f': 'json',
            'token': token
        }
        #logging.info(f"Sending export request to portal admin endpoint: {export_url}")
        response = requests.post(export_url, data=data, verify=False)
        result = response.json()
        logging.debug(f"Export response received: {json.dumps(result, indent=2)}")
        if result.get('status') == 'success':
            logging.info("Portal export completed successfully.")
        else:
            logging.error("Portal export failed. Please check the export response for details.")
    except requests.exceptions.RequestException as e:
        logging.error(f"HTTP request failed during portal export: {str(e)}")
    except json.JSONDecodeError:
        logging.error("Invalid response format received during portal export. Could not parse JSON.")
    except Exception as e:
        logging.error(f"An unexpected error occurred during the portal export process: {str(e)}")
