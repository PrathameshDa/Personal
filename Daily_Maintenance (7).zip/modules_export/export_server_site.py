import logging
import os
from arcgis.gis.server import Server
from modules_email.email_handler import send_failure_email
from tenacity import retry, stop_after_attempt, wait_fixed

@retry(stop=stop_after_attempt(5), wait=wait_fixed(10))
def export_server_site(settings, gis, server_name):
    """
    Export ArcGIS Server site with comprehensive exception handling.
    
    Args:
        settings: Configuration settings object
        gis: GIS connection object
        server_name: Name of the server to export
        
    Returns:
        list: Contains success message if export was successful, empty list if failed
    """
    operation = f"Daily Maintenance Exportsite {server_name}"
    
    try:
        logging.info(f"Exportsite {server_name} process started")
        
        # Validate required parameters
        if not settings:
            raise ValueError("Settings object is None or empty")
        if not gis:
            raise ValueError("GIS connection object is None or empty")
        if not server_name or not isinstance(server_name, str):
            raise ValueError("Server name is invalid or empty")
        
        # Validate portal URL configuration
        if not hasattr(settings.arcgis, 'portal_url') or not settings.arcgis.portal_url:
            raise ValueError("Portal URL is not configured in settings")
        
        # Construct the URL for the current server using portal_url
        try:
            # Extract base URL by removing '/portal' from portal_url
            base_url = settings.arcgis.portal_url.rstrip('/').replace('/portal', '')
            if not base_url:
                raise ValueError("Unable to extract base URL from portal URL")
            url = f"{base_url}/{server_name}"
#            logging.info(f"Constructed server URL: {url}")
        except Exception as e:
            error_message = f"Failed to construct server URL for {server_name}: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return []
       
        # Construct and validate the backup location
        try:
            if hasattr(settings.arcgis, 'linux_backup_location') and settings.arcgis.linux_backup_location:
                location = f"{settings.arcgis.linux_backup_location}/{server_name}"
            elif hasattr(settings.arcgis, 'backup_location') and settings.arcgis.backup_location:
                location = f"{settings.arcgis.backup_location}\\{server_name}"
            else:
                raise ValueError("No backup location configured in settings")
            
            # Validate backup location directory exists or can be created
            backup_dir = os.path.dirname(location)
            if not os.path.exists(backup_dir):
                try:
                    os.makedirs(backup_dir, exist_ok=True)
#                   logging.info(f"Created backup directory: {backup_dir}")
                except OSError as e:
                    raise ValueError(f"Cannot create backup directory {backup_dir}: {str(e)}")
            
#           logging.info(f"Backup location: {location}")
        except Exception as e:
            error_message = f"Failed to configure backup location for {server_name}: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return []
        
        # Attempt to create a Server object
        try:
            server = Server(url=url, gis=gis)
            if not server:
                raise ValueError("Server object creation returned None")
#           logging.info(f"Successfully created Server object for {server_name}")
        except Exception as e:
            error_message = f"Failed to create Server object for {server_name}: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return []
        
        # Validate server object and site property
        try:
            if not hasattr(server, 'site') or not server.site:
                raise ValueError("Server object does not have a valid site property")
#               logging.info(f"Server site object validated for {server_name}")
        except Exception as e:
            error_message = f"Server site validation failed for {server_name}: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return []
        
        # Attempt to export the site
        try:
            export_result = server.site.export(location=location)
            
            # Validate export result
            if export_result is None:
                raise ValueError("Export operation returned None - operation may have failed")
            
            logging.info(f"Export site backup completed successfully for {server_name}")
            success_message = f"Export site backup successful: {server_name}"
            
            return [success_message]
            
        except Exception as e:
            error_message = f"Failed to export site for {server_name}: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return []
    
    except Exception as e:
        # Catch-all exception handler for any unexpected errors
        error_message = f"Unexpected error during export operation for {server_name}: {str(e)}"
        logging.error(error_message)
        try:
            send_failure_email(settings, error_message, operation)
        except Exception as email_error:
            logging.error(f"Failed to send failure email: {str(email_error)}")
        return []