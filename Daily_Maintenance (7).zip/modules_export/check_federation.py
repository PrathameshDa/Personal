import logging
from modules_email.email_handler import send_failure_email
from tenacity import retry, stop_after_attempt, wait_fixed

@retry(stop=stop_after_attempt(5), wait=wait_fixed(10))
def check_federation(settings, gis):
    """
    Check federation validation with comprehensive exception handling.
    
    Args:
        settings: Configuration settings object
        gis: GIS connection object
        
    Returns:
        str: Success message if federation validation was successful, None if failed
    """
    operation = "Federation"
    
    try:
        logging.info("Federation Validation process started")
        
        # Validate required parameters
        if not settings:
            raise ValueError("Settings object is None or empty")
        if not gis:
            raise ValueError("GIS connection object is None or empty")
        
        # Validate GIS admin and federation objects
        try:
            if not hasattr(gis, 'admin') or not gis.admin:
                raise ValueError("GIS object does not have a valid admin property")
            if not hasattr(gis.admin, 'federation') or not gis.admin.federation:
                raise ValueError("GIS admin object does not have a valid federation property")
            
#            logging.info("GIS federation object validated successfully")
        except Exception as e:
            error_message = f"Federation object validation failed: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return None
        
        # Attempt federation validation
        try:
            validation_results = gis.admin.federation.validate_all()
            
            # Validate that we got results
            if validation_results is None:
                raise ValueError("Federation validation returned None")
            if not isinstance(validation_results, dict):
                raise ValueError("Federation validation returned unexpected result type")
            if 'status' not in validation_results:
                raise ValueError("Federation validation results missing 'status' field")
            
#            logging.info("Federation validation API call completed successfully")
        except Exception as e:
            error_message = f"Error during federation validation: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return None
        
        # Process validation results
        try:
            status = validation_results.get('status', '').lower()
            
            if status == "success":
                logging.info("Federation validation is successful")
                return "Federation validation is successful"
                
            elif status == "failed":
                error_message = "Federation validation has failed"
                logging.error(error_message)
                
                # Extract detailed error messages safely
                detailed_error_messages = [error_message]
                try:
                    servers_status = validation_results.get('serversStatus', [])
                    if isinstance(servers_status, list):
                        for server_status in servers_status:
                            if isinstance(server_status, dict):
                                server_id = server_status.get('serverId', 'Unknown')
                                server_status_value = server_status.get('status', 'Unknown')
                                detailed_error_messages.append(f"Server ID: {server_id}, Status: {server_status_value}")
                                
                                messages = server_status.get('messages', [])
                                if isinstance(messages, list):
                                    for message in messages:
                                        detailed_error_messages.append(f" - {str(message)}")
                except Exception as e:
                    detailed_error_messages.append(f"Error parsing server status details: {str(e)}")
                
                full_error_message = "\n".join(detailed_error_messages)
                logging.error(full_error_message)
                send_failure_email(settings, full_error_message, operation)
                return None
                
            else:
                # Handle warnings or unknown status
                warning_message = f"Federation validation completed with status: {status}"
                logging.warning(warning_message)
                
                # Extract detailed warning messages safely
                detailed_warning_messages = [warning_message]
                try:
                    servers_status = validation_results.get('serversStatus', [])
                    if isinstance(servers_status, list):
                        for server_status in servers_status:
                            if isinstance(server_status, dict):
                                server_id = server_status.get('serverId', 'Unknown')
                                server_status_value = server_status.get('status', 'Unknown')
                                detailed_warning_messages.append(f"Server ID: {server_id}, Status: {server_status_value}")
                                
                                messages = server_status.get('messages', [])
                                if isinstance(messages, list):
                                    for message in messages:
                                        detailed_warning_messages.append(f" - {str(message)}")
                except Exception as e:
                    detailed_warning_messages.append(f"Error parsing server status details: {str(e)}")
                
                full_warning_message = "\n".join(detailed_warning_messages)
                logging.warning(full_warning_message)
                
                # For warnings, we might still want to send notification but return success
                # Adjust this behavior based on your requirements
                if status == "success_with_warnings":
                    return "Federation validation successful with warnings"
                else:
                    send_failure_email(settings, full_warning_message, operation)
                    return None
                    
        except Exception as e:
            error_message = f"Error processing federation validation results: {str(e)}"
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
            return None
    
    except Exception as e:
        # Catch-all exception handler for any unexpected errors
        error_message = f"Unexpected error during federation validation: {str(e)}"
        logging.error(error_message)
        try:
            send_failure_email(settings, error_message, operation)
        except Exception as email_error:
            logging.error(f"Failed to send failure email: {str(email_error)}")
        return None