from arcgis.gis import GIS
from modules_tasks.get_secrets import get_secrets
from modules_security.check_log_levels import check_log_levels
from modules_security.check_rest_endpoint import check_rest_endpoint
from modules_security.check_hsts import check_hsts_enabled
from modules_security.sharing_rest import token_exp_mins
from modules_security.sharing_rest import check_portal_anonymous_access
from modules_security.portal_home import print_update_user_profile_disabled
from modules_security.portal_home import print_can_share_public
import logging
def security_checks(settings, gis):        
    logging.info("Starting security checks process...")
    print_can_share_public(settings, gis)
    print_update_user_profile_disabled(settings,gis)
    check_portal_anonymous_access(settings, gis)
    check_rest_endpoint(settings, gis)
    check_log_levels(settings, gis)
    check_hsts_enabled(settings, gis)
    token_exp_mins(settings, gis)
    #logging.info("Security checks process completed successfully")
    