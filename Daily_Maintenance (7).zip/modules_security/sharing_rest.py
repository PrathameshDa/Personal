import logging
def check_portal_anonymous_access(settings, gis):
    import requests
    try:
        portal_url = settings.arcgis.portal_url.rstrip('/')
        # Get portal id
        portal_self_url = f"{portal_url}/sharing/rest/portals/self?f=json&token={gis._con.token}"
        resp = requests.get(portal_self_url, timeout=10)
        if resp.ok:
            portal_info = resp.json()
            portal_id = portal_info.get('id', '0123456789ABCDEF')
        else:
            logging.warning("Could not fetch portal id, using default.")
            portal_id = '0123456789ABCDEF'

        # Now fetch the portal info using the id
        url = f"{portal_url}/sharing/rest/portals/{portal_id}?f=json&token={gis._con.token}"
        resp = requests.get(url, timeout=10)
        if resp.ok:
            data = resp.json()
            access = data.get('access', None)
            if access == 'private':
                logging.info("Allow anonymous access to portal is disabled.")
            elif access == 'public':
                logging.info("Allow anonymous access to portal is enabled.")
            else:
                logging.warning("Allow anonymous access to portal: not found.")
        else:
            logging.error(f"Failed to fetch access value from {url}")
    except Exception as e:
        logging.error(f"Error fetching access value: {e}")
def token_exp_mins(settings, gis):
    import requests
    try:
        portal_url = settings.arcgis.portal_url.rstrip('/')
        # Get portal id
        portal_self_url = f"{portal_url}/sharing/rest/portals/self?f=json&token={gis._con.token}"
        resp = requests.get(portal_self_url, timeout=10)
        if resp.ok:
            portal_info = resp.json()
            portal_id = portal_info.get('id', '0123456789ABCDEF')
        else:
            logging.warning("Could not fetch portal id, using default.")
            portal_id = '0123456789ABCDEF'

        # Now fetch the portal info using the id
        url = f"{portal_url}/sharing/rest/portals/{portal_id}?f=json&token={gis._con.token}"
        resp = requests.get(url, timeout=10)
        if resp.ok:
            data = resp.json()
            value = data.get('maxTokenExpirationMinutes', None)
            logging.info(f"maxTokenExpirationMinutes: {value}")
        else:
            logging.error(f"Failed to fetch maxTokenExpirationMinutes from {url}")
    except Exception as e:
        logging.error(f"Error fetching maxTokenExpirationMinutes: {e}")


