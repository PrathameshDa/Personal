import logging
def check_log_levels(settings, gis):
    logging.info("Checking portal and server log levels...")
    try:
        # Check portal log level
        log_settings = gis.admin.logs.settings
        log_level = log_settings.get('logLevel', log_settings)
        logging.info(f"Portal log level: {log_level}")

        # Check log levels for all servers except 'notebook'
        from arcgis.gis.server import Server
        for srv in gis.admin.federation.servers.get("servers", []):
            url = srv.get("url", "")
            parts = url.split("/")
            if len(parts) > 3:
                webadaptor = parts[3]
                if webadaptor.lower() == "notebook":
                    continue
                try:
                    server = Server(url=url, gis=gis)
                    server_log_settings = server.logs.settings
                    server_log_level = server_log_settings.get('logLevel', server_log_settings)
                    logging.info(f"{webadaptor} log level: {server_log_level}")
                except Exception as e:
                    logging.error(f"Error checking log level for {webadaptor}: {e}")
    except Exception as e:
        logging.error(f"An error occurred while checking/updating log levels: {e}")