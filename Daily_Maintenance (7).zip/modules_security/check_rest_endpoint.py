import logging
def check_rest_endpoint(settings, gis):
    logging.info("Checking portal and server REST endpoints...")
    try:
        import requests
        servers = []
        for srv in gis.admin.federation.servers.get("servers", []):
            url = srv.get("url", "")
            parts = url.split("/")
            if len(parts) > 3:
                webadaptor = parts[3]
                if webadaptor.lower() != "notebook":
                    servers.append(webadaptor)

        portal_url = settings.arcgis.portal_url.rstrip('/')

        # Check portal /portal/sharing/rest endpoint
        if '/portal' in portal_url:
            portal_rest_url = portal_url + '/sharing/rest'
        else:
            portal_rest_url = portal_url + '/portal/sharing/rest'
        try:
            resp = requests.get(portal_rest_url, timeout=10)
            if resp.ok and 'Current Version' in resp.text:
                logging.info("Portal sharing REST endpoint: Enabled")
            else:
                logging.warning("Portal sharing REST endpoint: Disabled")
        except Exception as e:
            logging.error(f"Error connecting to {portal_rest_url}: {e}")

        # Check each server's REST endpoint
        for server_name in servers:
            if '/portal' in portal_url:
                rest_url = portal_url.replace('/portal', f'/{server_name}') + '/rest'
            else:
                rest_url = portal_url + f'/{server_name}/rest'
            try:
                resp = requests.get(rest_url, timeout=10)
                if resp.ok and 'Current Version' in resp.text:
                    logging.info(f"{server_name} REST endpoint: Enabled")
                else:
                    logging.warning(f"{server_name} REST endpoint: Disabled")
            except Exception as e:
                logging.error(f"Error connecting to {rest_url}: {e}")
    except Exception as e:
        logging.error(f"An error occurred while checking portal/server REST endpoints: {e}")
