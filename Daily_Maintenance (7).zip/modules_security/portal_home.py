import logging
def print_can_share_public(settings, gis):
    value = getattr(gis.properties, 'canSharePublic', None)
    if value is True:
        logging.info("Sharing and searching with public is enabled.")
    elif value is False:
        logging.info("Sharing and searching with public is disabled.")
    else:
        logging.warning("Could not determine if sharing and searching with public is enabled.")

def print_update_user_profile_disabled(settings, gis):
    value = getattr(gis.properties, 'updateUserProfileDisabled', None)
    if value is True:
        logging.info("Allow members to edit their biographical information is disabled.")
    elif value is False:
        logging.info("Allow members to edit their biographical information is enabled.")
    else:
        logging.warning("Could not determine if members can edit their biographical information.")

