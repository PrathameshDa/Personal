from arcgis.gis.server import Server
import logging
def check_hsts_enabled(settings, gis):
    import requests
    try:
        portal_url = settings.arcgis.portal_url.rstrip('/')
        # Check HSTS for portal machines
        machinenames = [machine["machineName"] for machine in gis.admin.machines.properties["machines"]]
        token = gis._con.token
        for machine_name in machinenames:
            url = f"{portal_url}/portaladmin/machines/{machine_name}/sslCertificates?f=json&token={token}"
            try:
                resp = requests.get(url, timeout=10)
                if resp.ok and 'HSTSEnabled":true' in resp.text:
                    logging.info(f"Portal machine - {machine_name} HSTS enabled : true")
                elif resp.ok and 'HSTSEnabled":false' in resp.text:
                    logging.info(f"Portal machine - {machine_name} HSTS enabled : false")
                else:
                    logging.warning(f"Portal machine - {machine_name} HSTS enabled : not found in the response")
            except Exception as e:
                logging.error(f"Error connecting to {url}: {e}")

        # Check HSTS for all federated server machines except 'notebook'
        servers = [s for s in gis.admin.federation.servers.get('servers', []) if 'notebook' not in s.get('url', '').lower()]
        for server in servers:
            server_url = server.get('url', '').rstrip('/')
            # Remove trailing /admin if present
            if server_url.endswith('/admin'):
                server_url = server_url[:-6]
            # Extract the webadaptor/server name from the URL for display
            server_name = server_url.split('/')[-1]
            try:
                url = f"{server_url}/admin/security/config?f=json&token={token}"
                try:
                    resp = requests.get(url, timeout=10)
                    if resp.ok and 'HSTSEnabled":true' in resp.text:
                        logging.info(f"{server_name} - HSTS enabled : true")
                    elif resp.ok and 'HSTSEnabled":false' in resp.text:
                        logging.info(f"{server_name} - HSTS enabled : false")
                    else:
                        logging.warning(f"{server_name} - HSTS enabled : not found in the response")
                except Exception as e:
                    logging.error(f"Error connecting to {url}: {e}")
            except Exception as e:
                logging.error(f"Error processing server {server_url}: {e}")
    except Exception as e:
        logging.error(f"An error occurred while checking HSTS setting: {e}")
        