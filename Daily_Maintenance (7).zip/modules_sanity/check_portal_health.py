import logging
from modules_email.email_handler import send_failure_email

def check_portal_health(gis, settings):
#    logging.info("Starting portal health check for all machines.")
    try:
        machinenames = [machine["machineName"] for machine in gis.admin.machines.properties["machines"]]
#        logging.info(f"Found {len(machinenames)} machines in the portal.")

        for machine_name in machinenames:
#            logging.info(f"Checking health for portal machine '{machine_name}'.")
            machine = gis.admin.machines.get(machine_name)
            status = machine.status()
            role = machine.properties["role"]
            role_str = f"{role} " if role else ""
            if status:
                logging.info(f"Portal {role_str}machine '{machine_name}' is healthy.")
            else:
                logging.error(f"Portal {role_str}machine '{machine_name}' is not healthy.")

#        logging.info("Portal health check completed for all machines.")

    except AttributeError as e:
        logging.error(f"An attribute error occurred during portal health check: {e}. Please check if the 'gis' object is valid.")
    except ConnectionError as e:
        logging.error(f"A connection error occurred during portal health check: {e}. Please ensure that the portal URL is correct and accessible.")
    except Exception as e:
        logging.error(f"An unexpected error occurred during portal health check: {e}")
