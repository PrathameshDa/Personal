import gevent.monkey
gevent.monkey.patch_all()

import datetime
import logging
import ssl, socket
import re


def display_platform_info(gis, settings):
#    logging.info("Starting platform information display.")
    try:
#        logging.info("Platform details:")
        logging.info(f"Platform: {gis.properties.platform}")
        logging.info(f"Version: {gis.admin.properties.version}")
        logging.info("ArcGIS Enterprise is running on the following URL:")
        logging.info(f"https://{gis.properties.portalHostname}")
#        logging.info("Platform information display completed successfully.")
    except AttributeError:
        logging.error("An error occurred while accessing GIS platform information.")

def display_servers_info(gis, settings):
#    logging.info("Starting display of federated server information.")
    try:
        if "servers" in gis.admin.federation.servers:
            logging.getLogger().setLevel(logging.ERROR)
            servers = gis.admin.federation.servers["servers"]
            logging.getLogger().setLevel(logging.INFO)
            if servers:
                for svr in servers:
                    logging.info(f"Federated server URL: {svr['url']}")
            else:
                logging.info("No federated servers were found in the federation.")
        else:
            logging.info("No federated servers were found in the federation.")
        logging.info("Federated server information display completed.")
    except KeyError as e:
        logging.error(f"A key error occurred when accessing federated servers information: {e}")

def check_portal_license(gis, settings):
    logging.info("Starting portal user type license check.")
    try:
        portal_license_info = gis.admin.system.licenses.properties
        user_types = portal_license_info.get('userTypes', [])
        if not user_types:
            logging.info("No user types were found in the portal license information.")
        for user_type in user_types:
            user_type_name = user_type.get('name', user_type.get('id', 'Unknown'))
            expiration = user_type.get('expiration')
            if expiration:
                handle_license_expiration(expiration, f"{user_type_name}")
            else:
                logging.info(f"No expiration information was found for user type: {user_type_name}.")
        #logging.info("Portal user type license check completed.")
    except KeyError as e:
        logging.error(f"A key error occurred when accessing portal license information: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while checking the portal license: {e}")

def handle_license_expiration(expiration_timestamp, license_type):
    if expiration_timestamp > 4102444800000:  # Year 2100
        logging.info(f"The {license_type} does not have an expiration date.")
    else:
        readable_date = datetime.datetime.fromtimestamp(expiration_timestamp / 1000.0)
        today = datetime.datetime.now()
        days_until_expiration = (readable_date - today).days
        formatted_date = readable_date.strftime("%d %B %Y")

        if days_until_expiration <= 10:
            logging.error(f"The {license_type} will expire on {formatted_date}. Please take immediate action.")
        elif days_until_expiration <= 45:
            logging.warning(f"The {license_type} will expire on {formatted_date}. Please plan accordingly.")
        else:
            logging.info(f"The {license_type} will expire on {formatted_date}.")

def check_server_license(gis, settings):
    #logging.info("Starting server license check for all hosting and federated servers.")
    try:
        servers = []
        try:
            logging.getLogger().setLevel(logging.ERROR)
            hosting_servers = gis.admin.servers.get(role="HOSTING_SERVER")
            logging.getLogger().setLevel(logging.INFO)
            if hosting_servers:
                servers.extend(hosting_servers)
        except Exception as e:
            logging.info(f"No hosting server was found: {e}")

        try:
            logging.getLogger().setLevel(logging.ERROR)
            federated_servers = gis.admin.servers.get(role="FEDERATED_SERVER")
            logging.getLogger().setLevel(logging.INFO)
            if federated_servers:
                servers.extend(federated_servers)
        except Exception as e:
            logging.info(f"No federated servers were found: {e}")

        if not servers:
            logging.info("No servers were found for license check.")
            return

        for server in servers:
            server_url = getattr(server, 'url', str(server))
            match = re.search(r"https?://[^/]+/([^/]+)/admin", server_url)
            server_type = match.group(1) if match else server_url

            logging.info(f"Checking license features for {server_type} server.")
            try:
                for key, value in server.system.licenses.items():
                    if key == "features" and isinstance(value, list):
                        for feature in value:
                            feature_name = feature.get('name', 'Unknown Feature')
                            can_expire = feature.get('canExpire', False)
                            expiration = feature.get('expiration')
                            if can_expire and expiration:
                                handle_license_expiration(expiration, f"{feature_name}")
                            elif can_expire:
                                logging.info(f"The feature {feature_name} can expire, but no expiration date was found.")
                            else:
                                logging.info(f"The feature {feature_name} does not expire.")
            except Exception as e:
                logging.error(f"An error occurred while processing server license information: {e}")
        logging.info("Server license check completed for all hosting and federated servers.")
    except Exception as e:
        logging.error(f"An unexpected error occurred while checking server licenses: {e}")

def check_private_ssl(gis, settings):
    #logging.info("Starting private endpoint SSL certificate check.")
    try:
        logging.getLogger().setLevel(logging.ERROR)
        server = gis.admin.servers.get(role="HOSTING_SERVER")[0]
        logging.getLogger().setLevel(logging.INFO)
        machine_info = server.machines.list()
        if not machine_info:
            logging.error("No machines were found for the hosting server.")
            return

        machine_name = machine_info[0]["machineName"]
        server_ssl_info = server.machines.get(machine_name).ssl_certificates
        web_server_ssl_cert_name = server.machines.get(machine_name).properties["webServerCertificateAlias"]

        for cert_name in server_ssl_info['certificates']:
            if cert_name == web_server_ssl_cert_name:
                server_ssl_cert_info = server.machines.get(machine_name).ssl_certificate(cert_name)
                if server_ssl_cert_info["aliasName"] == web_server_ssl_cert_name:
                    active_cert_expiration = server_ssl_cert_info["validUntilEpoch"]
                    handle_license_expiration(active_cert_expiration, "Private endpoint SSL Certificate")
        #logging.info("Private endpoint SSL certificate check completed.")
    except IndexError:
        logging.error("No hosting server was found or no machines are available.")
    except KeyError as e:
        logging.error(f"A key error occurred when accessing SSL certificate information: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred while checking SSL certificates: {e}")


def check_wc_ssl(gis, settings):
    #logging.info("Starting WebContext URL SSL certificate check.")
    domain = gis.properties.portalHostname.split('/')[0]
    try:
        with socket.create_connection((domain, 443)) as sock:
            with ssl.create_default_context().wrap_socket(sock, server_hostname=domain) as ssock:
                expiry_date = datetime.datetime.strptime(ssock.getpeercert()['notAfter'], '%b %d %H:%M:%S %Y GMT')
                today = datetime.datetime.now()
                days_until_expiration = (expiry_date - today).days
                formatted_date = expiry_date.strftime("%d %B %Y")
                wc_ssl_label = "WebContext URL SSL Certificate"
                if days_until_expiration <= 10:
                    logging.error(f"The {wc_ssl_label} for '{domain}' will expire on {formatted_date}. Please take immediate action.")
                elif days_until_expiration <= 45:
                    logging.warning(f"The {wc_ssl_label} for '{domain}' will expire on {formatted_date}. Please plan accordingly.")
                else:
                    logging.info(f"The {wc_ssl_label} for '{domain}' will expire on {formatted_date}.")
        #logging.info("WebContext URL SSL certificate check completed.")
    except Exception as e:
        logging.error(f"An error occurred while checking the WebContext URL SSL certificate: {e}")

def basic_info(gis, settings):
    #logging.info("Starting basic information checks for ArcGIS Enterprise platform.")
    display_platform_info(gis, settings)
    display_servers_info(gis, settings)
    check_portal_license(gis, settings)
    check_server_license(gis, settings)
    check_private_ssl(gis, settings)
    check_wc_ssl(gis, settings)
    #logging.info("Basic information checks for ArcGIS Enterprise platform completed.")
    