import logging
import re
import json

def validate_datastore(gis, settings):
    # logging.info("Starting validation of ArcGIS datastores for the hosting server.")
    logging.getLogger().setLevel(logging.ERROR)
    hosting_server = gis.admin.servers.get(role="HOSTING_SERVER")[0]
    logging.getLogger().setLevel(logging.INFO)
    try:
        datastores = hosting_server.datastores.list()
#        logging.info("Successfully listed datastores for the hosting server.")
    except TypeError as e:
        logging.error(f"A type error occurred while listing datastores for the hosting server: {str(e)}")
        return

    for ds in datastores:
        if "/nosqlDatabases/AGSDataStore_nosqldb_tcs" in ds.path:
            r_validation_output = hosting_server.datastores.validate()
            if r_validation_output['status'] == "success":
                logging.info(f"Validation of tilecache datastore '{ds.path}' succeeded. Status: {r_validation_output['status']}.")
            else:
                logging.error(f"Validation of tilecache datastore '{ds.path}' failed. Status: {r_validation_output['status']}.")
    
    #logging.info("Note : ArcGIS API for python supports output of validation in JSON format only for Relational datastores. For Fileshares & NoSQL datastores, it returns a boolean value.")
    
    server_list = []
    try:
        logging.getLogger().setLevel(logging.ERROR)
        server_list = gis.admin.servers.list()
        logging.getLogger().setLevel(logging.INFO)
 #       logging.info("Successfully listed all ArcGIS servers for additional datastore validation.")
    except Exception as e:
        logging.error(f"An error occurred while listing ArcGIS servers: {e}")

    arcgis_server_list = [server for server in server_list if 'notebook' not in getattr(server, '_url', '')]
    for server in arcgis_server_list:
        try:
            server_url = getattr(server, 'url', str(server))
            match = re.search(r"https?://[^/]+/([^/]+)/admin", server_url)
            server_type = match.group(1) if match else server_url
            logging.info(f"Starting validation of other datastores for server: {server_type}.")
            try:
                datastores = server.datastores.list()
#              logging.info(f"Successfully listed datastores for server: {server_type}.")
            except Exception as e:
                logging.error(f"An error occurred while listing datastores for server '{server.url}': {e}")
                continue
            found = False
            for ds in datastores:
                if "/enterpriseDatabases/AGSDataStore" in ds.path or "/nosqlDatabases/AGSDataStore_nosqldb_tcs" in ds.path or "queue" in ds.path or "/nosqlDatabases/AGSDataStore_cache_cs" in ds.path:
                    continue
                found = True
                prefix = f"Datastore item of {server_type}: "
                try:
                    parts = ds.path.strip('/').split('/')
                    if len(parts) == 2:
                        ds_type, ds_name = parts
                    else:
                        ds_type, ds_name = parts[0], '_'.join(parts[1:])
                    result = ds.validate()
                    status = "Success" if result else "Failed"
                    type_label = ds_type[:-1] if ds_type.endswith('s') else ds_type
                    if status == "Success":
                        logging.info(f"{prefix}{type_label} {ds_name} Status - {status}")
                    else:
                        logging.error(f"{prefix}{type_label} {ds_name} Status - {status}")
                except Exception as e:
                    status = "Failed"
                    logging.error(f"{prefix}{type_label if 'type_label' in locals() else 'Unknown'} {ds_name if 'ds_name' in locals() else 'Unknown'} Status - {status}")
                    continue
            if not found:
                logging.info(f"No non-relational or non-nosql datastores were found on server: {server_type}.")
        except Exception as e:
            logging.error(f"An error occurred while processing server '{getattr(server, 'url', 'unknown')}': {e}")
            continue
