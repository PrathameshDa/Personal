import logging
from modules_email.email_handler import send_failure_email
def check_indexer_status(gis, settings):
    logging.info("Starting portal indexer status check.")
    try:
        data = gis.admin.system.indexer.status
#        logging.info("Successfully accessed the portal indexer status.")
        check_counts(data, settings)
    except AttributeError as e:
        logging.error(f"An attribute error occurred while accessing GIS properties during indexer status check: {e}.")
    except KeyError as e:
        logging.error(f"A key error occurred while accessing GIS properties during indexer status check: {e}. Please check the structure of the GIS object.")
    except Exception as e:
        logging.error(f"An unexpected error occurred during portal indexer status check: {e}")

def check_counts(data, settings):
    operation = "Portal Indexer"
    try:
#       logging.info("Checking index counts in the portal indexer status.")
        all_equal = True
        if 'indexes' not in data:
            logging.error("No indexes were found in the portal indexer status.")
            return

        for index in data['indexes']:
            if 'databaseCount' in index and 'indexCount' in index:
                if index['databaseCount'] != index['indexCount']:
                    logging.error(f"A mismatch was found in index '{index['name']}': databaseCount ({index['databaseCount']}) does not equal indexCount ({index['indexCount']}).")
                    all_equal = False
                else:
                    logging.info(f"Index '{index['name']}' has matching databaseCount and indexCount values.")
            else:
                logging.error(f"Missing counts for index '{index.get('name', 'Unknown')}': databaseCount or indexCount was not found.")

        if all_equal:
            logging.info("Portal indexer status check completed successfully. All index counts are equal.")
        else:
            error_message = ("Some index counts are not equal. Please check from the portal admin interface and reindex as necessary.")
            logging.error(error_message)
            send_failure_email(settings, error_message, operation)
    except KeyError as e:
        logging.error(f"A key error occurred while checking index counts: {e}. Please check the structure of the data.")
    except Exception as e:
        logging.error(f"An unexpected error occurred while checking index counts: {e}")