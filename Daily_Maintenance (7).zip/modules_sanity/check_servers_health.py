import logging
from modules_email.email_handler import send_failure_email

def check_servers_health(gis, settings):
#    logging.info("Starting health check for all ArcGIS server machines (excluding notebook servers).")
    logging.getLogger().setLevel(logging.ERROR)
    server_list = gis.admin.servers.list()
    logging.getLogger().setLevel(logging.INFO)
    arcgis_server_list = [server for server in server_list if 'notebook' not in server._url]

    for server in arcgis_server_list:
        try:
            machine_names = [machine["machineName"] for machine in server.machines.properties["machines"]]
#            logging.info(f"Checking health for server: {getattr(server, 'url', str(server))} with machines: {machine_names}")
        except KeyError as e:
            logging.error(f"Failed to retrieve machines for server {getattr(server, 'url', str(server))}: {e}")
            continue  # Skip to the next server

        for server_name in machine_names:
            try:
                operation = "Server Health Check"
                status = server.machines.get(server_name).status
                if status and status['configuredState'] == 'STARTED' and status['realTimeState'] == 'STARTED':
                    logging.info(f"Server machine '{server_name}' is healthy. Both configured and real-time states are STARTED.")
                else:
                    error_message = (f"Server machine '{server_name}' is not healthy. Either configured or real-time state is not STARTED.")
                    logging.error(error_message)
                    send_failure_email(settings, error_message, operation)
            except AttributeError as e:
                logging.error(f"Failed to get status for machine '{server_name}': {e}")
            except Exception as e:
                logging.error(f"An unexpected error occurred while checking health for machine '{server_name}': {e}")
            continue
#    logging.info("Server health check process completed for all ArcGIS server machines.")
    