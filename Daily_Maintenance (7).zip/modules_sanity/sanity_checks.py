import gevent.monkey
gevent.monkey.patch_all()

from arcgis.gis import GIS
from modules_sanity.basic_info import basic_info
from modules_sanity.check_portal_health import check_portal_health
from modules_sanity.check_servers_health import check_servers_health
from modules_sanity.check_indexer_status import check_indexer_status
from modules_sanity.relational_validate import relational_validate_datastore
from modules_sanity.validate_datastore import validate_datastore
from modules_sanity.create_and_delete_service import create_and_delete_service

import logging
from modules_email.email_handler import send_failure_email, send_expiry_email

def sanity_checks(settings):
#    logging.info("Starting the ArcGIS Enterprise sanity checks process.")
    try:
        # Use verify_cert=False for development environments
        gis = GIS(settings.arcgis.portal_url,
                 settings.secret_provider.portal_username,
                 settings.secret_provider.portal_password,
                 verify_cert=False)
        logging.info("Successfully created the GIS object for sanity checks.")
    except Exception as e:
        error_message = f"An error occurred while creating the GIS object: {e}"
        logging.error(error_message)
        try:
            send_failure_email(settings, error_message, "Create GIS Object")
        except Exception:
            pass
        return None  # Exit the function if GIS object creation fails

    for func, name in [
        (basic_info, "Basic Info"),
        (check_indexer_status, "Check Indexer Status"),
        (check_portal_health, "Check Portal Health"),
        (check_servers_health, "Check Servers Health"),
        (relational_validate_datastore, "Relational Validate Datastore"),
        (validate_datastore, "Validate Datastore"),
        (create_and_delete_service, "Create and Delete Service")
    ]:
        try:
            func(gis, settings)
        except Exception as e:
            logging.error(f"{name} failed: {e}")
            try:
                send_failure_email(settings, f"{name} failed: {e}", name)
            except Exception:
                pass

    #logging.info("Sanity checks for ArcGIS Enterprise platform completed successfully.")
    return gis