"""
Email Handler Module

This module provides all email functionality for the Daily Maintenance system.
It contains functions for sending different types of email notifications:
- Daily maintenance reports
- Failure notifications
- Expiry notifications
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os
import logging
from datetime import datetime


def send_email_notification(settings, results, tasks, deleted_files, uploaded_files):
    """
    Send daily maintenance email notification with results and logs.
    
    Args:
        settings: Configuration settings object
        results: List of operation results
        deleted_files: List of deleted files
        uploaded_files: List of uploaded files
    """
    #logging.info("Preparing to send daily maintenance email notification with results and logs.")
    if len(uploaded_files) > 0:
        retention_count = 1
    elif len(deleted_files) > 0:
        retention_count = 1
    else:
        retention_count = 0

    count = len([result for result in results if result is not None]) + retention_count
    total_count = tasks + 1  # Including retention task
    log_file_path = os.path.join("Logs", datetime.now().strftime("logfile_%Y-%m-%d.log"))

    try:
        with open(log_file_path, 'r') as log_file:
            log_contents = log_file.read()
    #    logging.info(f"Successfully read log file for email body: {log_file_path}")
    except Exception as e:
        logging.error(f"Failed to read log file '{log_file_path}': {e}")
        log_contents = "Could not read log file."

    # Extract color-coded log messages from the log contents
    colored_logs = ""
    for line in log_contents.split('\n'):
        if "ERROR" in line:
            colored_logs += f"<span style='color: red;'>{line}</span><br>"
        elif "WARNING" in line:
            colored_logs += f"<span style='color: orange;'>{line}</span><br>"
        elif "INFO" in line:
            colored_logs += f"<span style='color: green;'>{line}</span><br>"
        else:
            colored_logs += f"{line}<br>"
    
    # Prepare the email body with color-coded logs
    body = f"<html><body>"
    body += colored_logs
    body += "</body></html>"
    
    msg = MIMEMultipart('alternative')
    
    if count == total_count:
        msg['Subject'] = f"{settings.arcgis.client_name} - Daily Maintenance - Success ({count}/{total_count})"
    elif count == 0:
        msg['Subject'] = f"{settings.arcgis.client_name} - Daily Maintenance - Error ({total_count-count}/{total_count})"
    else:
        msg['Subject'] = f"{settings.arcgis.client_name} - Daily Maintenance - Success ({count}/{total_count}) - Error ({total_count-count}/{total_count})"
    
    msg['From'] = settings.secret_provider.smtp_username
    msg['To'] = ', '.join(settings.email.email_recipients)
    msg.attach(MIMEText(body, "html"))
    
    try:
        mail = smtplib.SMTP(settings.email.smtp_server, settings.email.smtp_port)
        mail.connect(settings.email.smtp_server, settings.email.smtp_port)
        mail.ehlo()
        mail.starttls()
        if settings.secret_provider.smtp_password:
            mail.login(settings.secret_provider.smtp_username, settings.secret_provider.smtp_password)
        mail.sendmail(msg['From'], settings.email.email_recipients, msg.as_string())
        mail.quit()
        logging.info(f"Daily maintenance email notification sent successfully to recipients: {settings.email.email_recipients}.")
    except Exception as e:
        logging.error(f"Failed to send daily maintenance email notification: {e}")


def send_failure_email(settings, error_message, operation):
    """
    Send failure notification email for a specific operation.
    
    Args:
        settings: Configuration settings object
        error_message: Description of the error/failure
        operation: Name of the operation that failed
    """
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f"{settings.arcgis.client_name} - {operation} - Failure"
    msg['From'] = settings.secret_provider.smtp_username
    msg['To'] = ', '.join(settings.email.email_recipients)
    
    body = f"""
    <html>
        <body>
            <span style='color: red;'>{error_message}</span>
        </body>
    </html>
    """
    
    msg.attach(MIMEText(body, "html"))
    
    try:
        mail = smtplib.SMTP(settings.email.smtp_server, settings.email.smtp_port)
        mail.connect(settings.email.smtp_server, settings.email.smtp_port)
        mail.ehlo()
        mail.starttls()
        if settings.secret_provider.smtp_password:
            mail.login(settings.secret_provider.smtp_username, settings.secret_provider.smtp_password)
        mail.sendmail(msg['From'], settings.email.email_recipients, msg.as_string())
        mail.quit()
        logging.info(f"Failure notification email sent successfully for operation: {operation} to recipients: {settings.email.email_recipients}.")
    except Exception as e:
        logging.error(f"Failed to send failure notification email for operation '{operation}': {e}")


def send_expiry_email(settings, error_message, operation):
    """
    Send expiry notification email for a specific operation.
    
    Args:
        settings: Configuration settings object
        error_message: Description of the expiry issue
        operation: Name of the operation related to expiry
    """
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f"{settings.arcgis.client_name} - {operation} - Expiry"
    msg['From'] = settings.secret_provider.smtp_username
    msg['To'] = ', '.join(settings.email.email_recipients)
    
    body = f"""
    <html>
        <body>
            <span style='color: red;'>{error_message}</span>
        </body>
    </html>
    """
    
    msg.attach(MIMEText(body, "html"))
    
    try:
        mail = smtplib.SMTP(settings.email.smtp_server, settings.email.smtp_port)
        mail.connect(settings.email.smtp_server, settings.email.smtp_port)
        mail.ehlo()
        mail.starttls()
        if settings.secret_provider.smtp_password:
            mail.login(settings.secret_provider.smtp_username, settings.secret_provider.smtp_password)
        mail.sendmail(msg['From'], settings.email.email_recipients, msg.as_string())
        mail.quit()
        logging.info(f"Expiry notification email sent successfully for operation: {operation} to recipients: {settings.email.email_recipients}.")
    except Exception as e:
        logging.error(f"Failed to send expiry notification email for operation '{operation}': {e}")


def send_email(email_type, settings, **kwargs):
    """
    Unified email sending function that routes to the appropriate email type.
    
    Args:
        email_type: Type of email ('notification', 'failure', 'expiry')
        settings: Configuration settings object
        **kwargs: Additional parameters based on email type
    """
    if email_type == 'notification':
        send_email_notification(
            settings, 
            kwargs.get('results', []), 
            kwargs.get('deleted_files', []), 
            kwargs.get('uploaded_files', [])
        )
    elif email_type == 'failure':
        send_failure_email(
            settings, 
            kwargs.get('error_message', ''), 
            kwargs.get('operation', '')
        )
    elif email_type == 'expiry':
        send_expiry_email(
            settings, 
            kwargs.get('error_message', ''), 
            kwargs.get('operation', '')
        )
    else:
        logging.error(f"Unknown email type specified: '{email_type}'. Email was not sent.")
        raise ValueError(f"Unknown email type: {email_type}")