@echo off
REM Batch script to run main.py using UV
REM Daily Maintenance Script Runner

echo ====================================
echo Daily Maintenance Script Runner
echo Using UV Package Manager
echo ====================================
echo.

REM Set the working directory to the script location
cd /d "%~dp0"

REM Display current directory
echo Current directory: %CD%
echo.

REM Check if UV is installed
echo Checking UV installation...
uv --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: UV is not installed or not in PATH
    echo Please install UV first: pip install uv
    pause
    exit /b 1
)

echo UV is installed successfully!
echo.

REM Check if pyproject.toml exists
if not exist "pyproject.toml" (
    echo ERROR: pyproject.toml not found
    echo Please ensure pyproject.toml is in the project directory
    pause
    exit /b 1
)

echo Found pyproject.toml
echo.

REM Check if main.py exists
if not exist "main.py" (
    echo ERROR: main.py not found
    echo Please ensure main.py is in the project directory
    pause
    exit /b 1
)

echo Found main.py
echo.

REM Set Python path
set PYTHONPATH=%CD%

echo Starting Daily Maintenance Script...
echo ====================================
echo.

REM Option 1: Try UV with pyproject.toml (modern approach)
echo Attempting to sync and run with UV...
echo Step 1: Syncing dependencies...
uv sync

if %ERRORLEVEL% EQU 0 (
    echo Dependencies synced successfully!
    echo Step 2: Running main.py...
    uv run main.py
    
    if %ERRORLEVEL% EQU 0 (
        echo.
        echo ====================================
        echo Script completed successfully with UV!
        echo ====================================
        goto :end
    ) else (
        echo UV run failed, error code: %ERRORLEVEL%
        goto :fallback
    )
) else (
    echo UV sync failed, error code: %ERRORLEVEL%
    goto :fallback
)

:fallback
echo.
echo Trying fallback with requirements.txt...

REM Option 2: Fallback to UV with requirements.txt
if exist "requirements.txt" (
    uv run --with-requirements requirements.txt --no-project main.py
    
    if %ERRORLEVEL% EQU 0 (
        echo.
        echo ====================================
        echo Script completed successfully with UV (fallback)!
        echo ====================================
        goto :end
    ) else (
        echo UV fallback failed.
        echo Script failed with all methods! Error code: %ERRORLEVEL%
        echo ====================================
        echo.
        echo Troubleshooting tips:
        echo 1. Check the log files in the Logs directory
        echo 2. Verify your config.yaml settings
        echo 3. Ensure all credentials are properly configured
        echo 4. Check your network connection
        echo 5. Try running: uv sync --verbose
        goto :end
    )
) else (
    echo requirements.txt not found. Script failed with all methods! Error code: %ERRORLEVEL%
    echo ====================================
    echo.
    echo Troubleshooting tips:
    echo 1. Check the log files in the Logs directory
    echo 2. Verify your config.yaml settings
    echo 3. Ensure all credentials are properly configured
    echo 4. Check your network connection
    echo 5. Try running: uv sync --verbose
    goto :end
)

:end
echo.
echo Exiting Daily Maintenance Script Runner.
