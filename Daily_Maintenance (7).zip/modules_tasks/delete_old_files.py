import os
import logging
from datetime import datetime, timedelta
from modules_email.email_handler import send_failure_email

def delete_old_files(settings):
    operation = "Retention "
    current_time = datetime.now()
    unc_path = settings.arcgis.backup_location
    retention_days= settings.arcgis.retention_days
    threshold = current_time - timedelta(days=retention_days)
    deleted_files = []
    retained_files = []

    logging.info(f"Starting the file retention process. Scanning for files older than {retention_days} days in the backup location: '{unc_path}'.")

    # Check if the backup location exists
    if os.path.exists(unc_path):
#        logging.info(f"The backup location '{unc_path}' exists. Beginning directory walk to identify old files.")
        for root, _, files in os.walk(unc_path):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    stat = os.stat(file_path)
                    last_modified = datetime.fromtimestamp(stat.st_mtime)
                    if last_modified < threshold:
                        logging.info(f"Deleting file '{file_path}' because it was last modified on {last_modified} and is older than the retention threshold.")
                        os.remove(file_path)
                        deleted_files.append(file_path)
                    else:
                        retained_files.append(file_path)
                except OSError as e:
                    error_message = f"An error occurred while accessing file '{file_path}': {e}"
                    logging.error(error_message)
                    send_failure_email(settings, error_message, operation)
                    return
        if len(deleted_files) == 0:
            logging.info("No files were found that needed to be deleted based on the retention policy.")
            deleted_files.append("No files to delete")
        else:
            logging.info(f"The following files were deleted as part of the retention policy: {deleted_files}")
        logging.info(f"The following files were retained: {retained_files}")
#        logging.info("File retention process completed successfully.")
        return deleted_files
    else:
        error_message = f"The backup location '{unc_path}' does not exist or is not accessible. File retention process cannot proceed."
        logging.error(error_message)
        send_failure_email(settings, error_message, operation)
        return
    
