
import boto3
import os
import logging
from modules_email.email_handler import send_failure_email, send_expiry_email


# Ensure logging is configured at the application entry point.
s3_upload = []

def upload_to_s3(settings):
    logging.info("Starting the S3 upload process for GIS backup files.")
    s3_client = boto3.client('s3')
#    logging.debug(f"Initialized S3 client: {s3_client}")
    
    def recursive_upload(local_path, s3_prefix):
        logging.info(f"Beginning recursive upload from local path: {local_path} to S3 prefix: {s3_prefix}.")
        for root, dirs, files in os.walk(local_path):
            for filename in files:
                file_path = os.path.join(root, filename)
                s3_key = os.path.join(s3_prefix, os.path.relpath(file_path, local_path)).replace("\\", "/")
                try:
                    s3_client.upload_file(file_path, settings.aws.bucket_name, s3_key)
                    logging.info(f"Successfully uploaded file '{file_path}' to 's3://{settings.aws.bucket_name}/{s3_key}'.")
                    os.remove(file_path)
                    s3_upload.append(file_path)
                    logging.info(f"Removed local file after upload: '{file_path}'.")
                except Exception as e:
                    logging.error(f"Failed to upload file '{file_path}' to S3 bucket '{settings.aws.bucket_name}' with key '{s3_key}': {e}")
                    try:
                        send_failure_email(settings, f"Failed to upload file '{file_path}' to S3 bucket '{settings.aws.bucket_name}' with key '{s3_key}': {e}", "Upload to S3")
                    except Exception:
                        pass
            for dir_name in dirs:
                dir_path = os.path.join(root, dir_name)
                if os.path.isdir(dir_path) and not os.listdir(dir_path):
                    try:
                        s3_key = os.path.join(s3_prefix, os.path.relpath(dir_path, local_path)).replace("\\", "/") + "/"
                        s3_client.put_object(Bucket=settings.aws.bucket_name, Key=s3_key)
                        logging.info(f"Created empty directory in S3: 's3://{settings.aws.bucket_name}/{s3_key}'.")
                    except Exception as e:
                        logging.error(f"Failed to create empty directory '{dir_path}' in S3: {e}")
                        try:
                            send_failure_email(settings, f"Failed to create empty directory '{dir_path}' in S3: {e}", "Upload to S3")
                        except Exception:
                            pass
    
    # Start the upload process from the GIS_Backup folder
    gis_backup_path = settings.arcgis.backup_location  # Path to the GIS_Backup folder
    #logging.info(f"Uploading files from GIS backup path: '{gis_backup_path}'.")
    recursive_upload(gis_backup_path, settings.aws.s3_prefix)

    if len(s3_upload) == 0:
        logging.info("No files were found to upload to S3.")
        s3_upload.append("No files to upload")
    else:
        logging.info(f"Upload to S3 completed successfully. Total files uploaded: {len(s3_upload)}.")
    return s3_upload