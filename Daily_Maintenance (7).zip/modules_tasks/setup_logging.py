import os
import logging
from datetime import datetime, timedelta
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

def setup_logging():
    class LogColors:
        INFO = Fore.GREEN      # Green
        WARNING = Fore.YELLOW   # Yellow
        ERROR = Fore.RED       # Red
        CRITICAL = Fore.MAGENTA # Magenta
        RESET = Style.RESET_ALL # Reset to default

    # Custom logging formatter to add color for terminal output
    class ColoredFormatter(logging.Formatter):
        def format(self, record):
            if record.levelno == logging.INFO:
                record.msg = f"{LogColors.INFO}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.WARNING:
                record.msg = f"{LogColors.WARNING}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.ERROR:
                record.msg = f"{LogColors.ERROR}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.CRITICAL:
                record.msg = f"{LogColors.CRITICAL}{record.msg}{LogColors.RESET}"
            return super().format(record)

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)  # Capture all levels of logs

    log_directory = "Logs"
    if not os.path.exists(log_directory):
        os.makedirs(log_directory, exist_ok=True)
#        logging.info(f"Created log directory at '{log_directory}'.")
#    else:
#        logging.info(f"Log directory '{log_directory}' already exists.")

    file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    console_formatter = ColoredFormatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    log_file_path = os.path.join(log_directory, datetime.now().strftime("logfile_%Y-%m-%d.log"))
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(file_formatter)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

#    logging.info("Logging setup is complete. All log messages will be written to file and console.")
    clean_old_logs(log_directory)
    
def clean_old_logs(log_directory):
    retention_period = timedelta(days=7)
    cutoff_time = datetime.now() - retention_period
#    logging.info(f"Cleaning up log files older than {retention_period.days} days in the directory '{log_directory}'.")
    for filename in os.listdir(log_directory):
        file_path = os.path.join(log_directory, filename)
        if os.path.isfile(file_path):
            file_mod_time = datetime.fromtimestamp(os.path.getmtime(file_path))
            if file_mod_time < cutoff_time:
                os.remove(file_path)
                logging.info(f"Deleted old log file: '{filename}' because it was older than the retention period.")
#    logging.info("Old log file cleanup process completed.")


    # ...existing code...
   