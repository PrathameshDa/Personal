import boto3
import json
import base64
from dynaconf import Dynaconf
import logging
from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient

# Initialize Dynaconf with the path to your config.yaml
settings = Dynaconf(settings_files=['config.yaml'])

def get_secrets():
    logging.info("Starting the credentials fetching process for the application.")
    # Check if cloud_provider is empty
    if not settings.cloud_provider:
        try:
#            logging.info("No cloud provider specified. Decoding credentials from Base64 values in the configuration.")
            settings.secret_provider.portal_username = base64.b64decode(settings.secret_provider.portal_username).decode('utf-8')
            settings.secret_provider.portal_password = base64.b64decode(settings.secret_provider.portal_password).decode('utf-8')
            if settings.secret_provider.smtp_password:
                settings.secret_provider.smtp_username = base64.b64decode(settings.secret_provider.smtp_username).decode('utf-8')
                settings.secret_provider.smtp_password = base64.b64decode(settings.secret_provider.smtp_password).decode('utf-8')
            logging.info("Credentials were successfully decoded from Base64 values.")
        except Exception as e:
            logging.error(f"An error occurred while decoding Base64 values for credentials: {e}")
            return None

    elif settings.cloud_provider == 'azure':
        try:
#            logging.info("Azure cloud provider detected. Decoding Azure credentials from Base64 values.")
            tenant_id = base64.b64decode(settings.azure.tenant_id).decode('utf-8')
            client_id = base64.b64decode(settings.azure.client_id).decode('utf-8')
            client_secret = base64.b64decode(settings.azure.client_secret).decode('utf-8')
            key_vault = settings.azure.key_vault
#            logging.info("Azure credentials were successfully decoded from Base64 values.")
        except Exception as e:
            logging.error(f"An error occurred while decoding Azure credentials from Base64: {e}")
            return None

        try:
#            logging.info(f"Attempting to connect to Azure Key Vault at '{key_vault}' to retrieve secrets.")
            new_credential = ClientSecretCredential(
                tenant_id=tenant_id,
                additionally_allowed_tenants=tenant_id,
                client_id=client_id,
                client_secret=client_secret
            )
            secret_client = SecretClient(
                vault_url=key_vault,
                credential=new_credential
            )
            settings.secret_provider.portal_username = secret_client.get_secret(settings.secret_provider.portal_username).value
            settings.secret_provider.portal_password = secret_client.get_secret(settings.secret_provider.portal_password).value
            settings.secret_provider.smtp_username = secret_client.get_secret(settings.secret_provider.smtp_username).value
            if settings.secret_provider.smtp_password:
                settings.secret_provider.smtp_password = secret_client.get_secret(settings.secret_provider.smtp_password).value
                settings.azure.connection_string = secret_client.get_secret(settings.azure.connection_string).value
            logging.info("Credentials were successfully fetched from Azure Key Vault.")
        except Exception as e:
            logging.error(f"An error occurred while retrieving secrets from Azure Key Vault: {e}")
            return None
    elif settings.cloud_provider == 'aws':
        try:
#            logging.info("AWS cloud provider detected. Attempting to retrieve secrets from AWS Secrets Manager.")
            secret_name = settings.aws.secret_name
            session = boto3.session.Session()
            client = session.client(
                service_name='secretsmanager',
                region_name=settings.aws.region
            )
            response = client.get_secret_value(SecretId=secret_name)
            secret_data = json.loads(response['SecretString'])
            settings.secret_provider.portal_username = secret_data[settings.secret_provider.portal_username]
            settings.secret_provider.portal_password = secret_data[settings.secret_provider.portal_password]
            if settings.secret_provider.smtp_password:
                settings.secret_provider.smtp_username = secret_data[settings.secret_provider.smtp_username]
                settings.secret_provider.smtp_password = secret_data[settings.secret_provider.smtp_password]
            logging.info("Credentials were successfully fetched from AWS Secrets Manager.")
        except Exception as e:
            logging.error(f"An error occurred while retrieving secrets from AWS Secrets Manager: {e}")
            logging.error("Failed to retrieve secrets from AWS. Please check the logs for more details.")
            return None
#    logging.info("Credentials fetching process completed successfully.")
    return settings