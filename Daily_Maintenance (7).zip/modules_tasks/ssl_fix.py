"""
SSL/TLS Compatibility Fix for ArcGIS + Truststore Issue
This module provides a workaround for the recursion bug in truststore 0.10.0
when used with ArcGIS 2.4.2
"""

import os
import ssl
import warnings
import sys

def disable_truststore():
    """
    Disable truststore to prevent SSL recursion issues with ArcGIS
    """
    # Set environment variables to disable truststore BEFORE any imports
    os.environ['PYTHONHTTPSVERIFY'] = '0'
    os.environ['SSL_CERT_FILE'] = ''
    os.environ['SSL_CERT_DIR'] = ''
    os.environ['REQUESTS_CA_BUNDLE'] = ''
    os.environ['CURL_CA_BUNDLE'] = ''
    
    # Disable SSL verification warnings
    try:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    except ImportError:
        pass
    
    # Remove truststore from sys.modules if it was already imported
    truststore_modules = [module for module in sys.modules.keys() if 'truststore' in module]
    for module in truststore_modules:
        del sys.modules[module]
    
    # Monkey patch SSL context creation BEFORE any other imports
    try:
        # Store original function
        if not hasattr(ssl, '_original_create_default_context'):
            ssl._original_create_default_context = ssl.create_default_context
        
        def patched_create_default_context(*args, **kwargs):
            """Create SSL context without truststore interference"""
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            # Don't load default certs to avoid truststore
            return context
            
        ssl.create_default_context = patched_create_default_context
        
        # Also patch SSLContext to prevent recursion
        if not hasattr(ssl.SSLContext, '_original_verify_mode'):
            ssl.SSLContext._original_verify_mode = ssl.SSLContext.verify_mode
            
        def safe_verify_mode_setter(self, value):
            """Safe setter that avoids recursion"""
            try:
                # Use object.__setattr__ to bypass property setter
                object.__setattr__(self, '_verify_mode', value)
            except:
                pass
                
        def safe_verify_mode_getter(self):
            """Safe getter that avoids recursion"""
            try:
                return getattr(self, '_verify_mode', ssl.CERT_NONE)
            except:
                return ssl.CERT_NONE
        
        # Replace the property with our safe version
        ssl.SSLContext.verify_mode = property(safe_verify_mode_getter, safe_verify_mode_setter)
        
    except Exception as e:
        warnings.warn(f"Could not patch SSL context: {e}")

def restore_ssl():
    """
    Restore normal SSL behavior after initialization
    """
    try:
        if hasattr(ssl, '_original_create_default_context'):
            ssl.create_default_context = ssl._original_create_default_context
            
        if hasattr(ssl.SSLContext, '_original_verify_mode'):
            ssl.SSLContext.verify_mode = ssl.SSLContext._original_verify_mode
    except:
        pass