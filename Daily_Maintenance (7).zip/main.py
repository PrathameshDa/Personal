import gevent.monkey
gevent.monkey.patch_all()

from modules_tasks.setup_logging import setup_logging
from modules_tasks.get_secrets import get_secrets
from modules_sanity.sanity_checks import sanity_checks
from modules_export.gis_backups import gis_backups
from modules_tasks.delete_old_files import delete_old_files
from modules_tasks.upload_to_blob import upload_to_blob
from modules_tasks.upload_to_s3 import upload_to_s3
from modules_email.email_handler import send_email_notification
from modules_security.security import security_checks

def main():
    setup_logging()
    try:
        settings = get_secrets()  # Retrieve credentials from key vault
    except Exception as e:
        import logging
        logging.error(f"Failed to retrieve secrets: {e}")
        settings = None

    gis = None
    if settings:
        try:
            gis = sanity_checks(settings) # Perform all sanity checks in one go
        except Exception as e:
            logging.error(f"Sanity checks failed: {e}")

        try:
            security_checks(settings, gis)
        except Exception as e:
            logging.error(f"Security checks failed: {e}")
        results = []
        tasks = 0
        try:
            if gis:
                results, tasks = gis_backups(settings, gis)  # Run export site operation for portal & all servers at the same time
            else:
                logging.error("Skipping GIS backups because GIS object was not created.")
        except Exception as e:
            logging.error(f"GIS backups failed: {e}")

        # Uncomment and update the following as needed for upload/delete/email notification logic
    
        try:
            if settings.cloud_provider == "azure":
                upload = upload_to_blob(settings)
                delete = []
            elif settings.cloud_provider == "aws":
                upload = upload_to_s3(settings)
                delete = []
            else:
                delete = delete_old_files(settings)
                upload = []
        except Exception as e:
            logging.error(f"Upload/Delete operation failed: {e}")

        try:
            if len(results) > 0:
                send_email_notification(settings, results, tasks, delete, upload)
        except Exception as e:
            logging.error(f"Failed to send email notification: {e}")
        
if __name__ == '__main__':
    main()