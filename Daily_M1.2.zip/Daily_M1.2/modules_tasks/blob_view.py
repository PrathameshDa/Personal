import logging
from azure.storage.blob import BlobServiceClient

# Ensure logging is configured at the application entry point.
logging.getLogger('azure').setLevel(logging.WARNING)


def get_blob_service_client(settings):
    """Create and return the Azure Blob Storage client."""
    connect_str = settings.azure.connection_string
    return BlobServiceClient.from_connection_string(connect_str)


def list_containers(settings):
    """Return a list of all container names in Azure Blob Storage."""
    blob_service_client = get_blob_service_client(settings)
    return [container.name for container in blob_service_client.list_containers()]


def list_blobs_in_container(settings, container_name, prefix=""):
    """Return all blob names in a given container, optionally filtered by a prefix."""
    blob_service_client = get_blob_service_client(settings)
    container_client = blob_service_client.get_container_client(container_name)
    return [blob.name for blob in container_client.list_blobs(name_starts_with=prefix)]


def list_folders_and_files(settings, container_name, prefix=""):
    """Return a dictionary with folders and files for a container."""
    blob_names = list_blobs_in_container(settings, container_name, prefix=prefix)
    folders = set()
    files = []

    for blob_name in blob_names:
        relative_name = blob_name[len(prefix):] if prefix else blob_name
        if not relative_name:
            continue

        if "/" in relative_name:
            folder_name = relative_name.split("/", 1)[0]
            folders.add(folder_name)
        files.append(relative_name)

    return {
        "folders": sorted(folders),
        "files": sorted(files),
    }


def open_blob(settings, container_name, blob_name):
    """Download and return the content of a blob as bytes."""
    blob_service_client = get_blob_service_client(settings)
    container_client = blob_service_client.get_container_client(container_name)
    blob_client = container_client.get_blob_client(blob_name)
    download_stream = blob_client.download_blob()
    return download_stream.readall()


def print_blob_tree(settings, container_name, prefix=""):
    """Print container folders and files in a readable tree format."""
    result = list_folders_and_files(settings, container_name, prefix=prefix)

    print(f"Container: {container_name}")
    print("Folders:")
    if result["folders"]:
        for folder in result["folders"]:
            print(f"  - {folder}/")
    else:
        print("  - None")

    print("Files:")
    if result["files"]:
        for file_name in result["files"]:
            print(f"  - {file_name}")
    else:
        print("  - None")


if __name__ == "__main__":
    # Example usage:
    # 1. Create settings object with Azure params
    # 2. Call list_containers(settings)
    # 3. Call print_blob_tree(settings, 'my-container')
    # 4. Call open_blob(settings, 'my-container', 'folder/file.txt')
    print("This is a helper module for Azure Blob inspection.")
    print("Use the functions from another script or import it in your code.")
