import logging
def relational_validate_datastore(gis, settings):
    logging.info("Starting validation of ArcGIS datastores for the hosting server.")
    logging.getLogger().setLevel(logging.ERROR)
    hosting_server = gis.admin.servers.get(role="HOSTING_SERVER")[0]
    logging.getLogger().setLevel(logging.INFO)
    try:
        datastores = hosting_server.datastores.list()
#        logging.info("Successfully listed datastores for the hosting server.")
    except TypeError as e:
        logging.error(f"A type error occurred while listing datastores for the hosting server: {str(e)}")
        return

    for ds in datastores:
        if "/enterpriseDatabases/AGSDataStore" in ds.path:
            datastore_name = ds.path.split('/')[-1]
            try:
                machine = ds.info['machines'][0]
            except (KeyError, IndexError) as e:
                logging.error(f"Machine information is missing for relational datastore '{ds.path}': {str(e)}")
                continue
            try:
                r_validation_output = hosting_server.datastores.validate_egdb(datastore_name, machine['name'])
                if r_validation_output['status'] == "success":
                    logging.info(f"Validation of relational datastore '{ds.path}' succeeded. Status: {r_validation_output['status']}.")
                else:
                    logging.error(f"Validation of relational datastore '{ds.path}' failed. Status: {r_validation_output['status']}.")
                
                # Extract and print name, role, and status for each machine if present
                import os
                machines = r_validation_output.get('machines')
                machine_lines = []
                if machines and isinstance(machines, list):
                    logging.info("Relational Datastore's Machine Details:")
                    for m in machines:
                        name = m.get('name', 'N/A')
                        role = m.get('role', 'N/A')
                        status = m.get('status', 'N/A')
                        overall_health = m.get('machine.overallhealth', 'N/A')
                        line = f"Name: {name}, Role: {role}, Status: {status}, Overall Health: {overall_health}"
                        logging.error(line) if "failed" in line.lower() else logging.info(line)
                        machine_lines.append(line)

                # Save and compare machine details
                state_file = 'relational_machine_state.txt'
                previous_lines = []
                if os.path.exists(state_file):
                    with open(state_file, 'r') as f:
                        previous_lines = [l.strip() for l in f.readlines() if l.strip()]

                # Compare and warn if changed
                for line in machine_lines:
                    if line not in previous_lines:
                        logging.warning(f"Machine Status or Role changed or new: {line}")

                # Save current state for next run
                with open(state_file, 'w') as f:
                    for line in machine_lines:
                        f.write(line + '\n')
            except ConnectionError as e:
                logging.error(f"A connection error occurred while validating relational datastore '{ds.path}': {e}")
                continue
